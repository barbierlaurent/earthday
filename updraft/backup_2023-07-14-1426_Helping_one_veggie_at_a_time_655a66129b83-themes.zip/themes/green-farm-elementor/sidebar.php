<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Green Farm Elementor
 */
?>

<div class="sidebar-area">
  <?php
    dynamic_sidebar('green-farm-elementor-sidebar');
  ?>
</div>